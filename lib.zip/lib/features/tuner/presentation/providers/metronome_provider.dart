import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'metronome_sound_presets.dart';

class MetronomeState {
  final int bpm;
  final int timeSignature; // 2, 3, 4, 6
  final int currentBeat; // 0 a (timeSignature - 1)
  final bool isPlaying;
  final bool isMuted;
  final String soundPresetId;

  MetronomeState({
    this.bpm = 120,
    this.timeSignature = 4,
    this.currentBeat = 0,
    this.isPlaying = false,
    this.isMuted = false,
    this.soundPresetId = 'ableton',
  });

  String get soundPresetName => metronomePresetById(soundPresetId).name;

  String get tempoMarking {
    if (bpm <= 59) return 'Largo (40–59)';
    if (bpm <= 76) return 'Adagio (60–76)';
    if (bpm <= 107) return 'Andante (77–107)';
    if (bpm <= 120) return 'Moderato (108–120)';
    if (bpm <= 167) return 'Allegro (121–167)';
    if (bpm <= 200) return 'Vivace (168–200)';
    return 'Presto (201–240)';
  }

  MetronomeState copyWith({
    int? bpm,
    int? timeSignature,
    int? currentBeat,
    bool? isPlaying,
    bool? isMuted,
    String? soundPresetId,
  }) {
    return MetronomeState(
      bpm: bpm ?? this.bpm,
      timeSignature: timeSignature ?? this.timeSignature,
      currentBeat: currentBeat ?? this.currentBeat,
      isPlaying: isPlaying ?? this.isPlaying,
      isMuted: isMuted ?? this.isMuted,
      soundPresetId: soundPresetId ?? this.soundPresetId,
    );
  }
}

class MetronomeNotifier extends StateNotifier<MetronomeState> {
  Timer? _timer;
  final List<DateTime> _tapTimes = [];

  AudioPool? _accentPool;
  AudioPool? _normalPool;
  bool _audioReady = false;
  int _audioLoadGeneration = 0;
  Future<void>? _audioLoadFuture;

  MetronomeNotifier() : super(MetronomeState()) {
    _audioLoadFuture = _loadAudioForPreset(state.soundPresetId);
  }

  Future<void> selectSoundPreset(String presetId) async {
    final preset = metronomePresetById(presetId);
    final wasPlaying = state.isPlaying;

    // Mientras cambia el preset no dejamos al timer disparar golpes contra
    // pools que ya fueron descartados. El estado visual de reproducción se
    // conserva y el reloj continúa cuando el nuevo sonido está listo.
    if (wasPlaying) {
      _stopTimer();
    }

    state = state.copyWith(soundPresetId: preset.id);

    _audioLoadFuture = _loadAudioForPreset(preset.id);
    await _audioLoadFuture;

    if (wasPlaying && state.isPlaying && _audioReady) {
      _scheduleNextTick();
    }
  }

  Future<void> _loadAudioForPreset(String presetId) async {
    final generation = ++_audioLoadGeneration;
    _audioReady = false;

    final oldAccent = _accentPool;
    final oldNormal = _normalPool;
    _accentPool = null;
    _normalPool = null;

    await oldAccent?.dispose();
    await oldNormal?.dispose();

    final preset = metronomePresetById(presetId);

    try {
      final audioCache = AudioCache(prefix: 'assets/');

      final accent = await AudioPool.create(
        source: AssetSource(preset.accentAsset),
        audioCache: audioCache,
        minPlayers: 2,
        maxPlayers: 4,
        playerMode: PlayerMode.lowLatency,
      );
      final normal = await AudioPool.create(
        source: AssetSource(preset.normalAsset),
        audioCache: audioCache,
        minPlayers: 2,
        maxPlayers: 4,
        playerMode: PlayerMode.lowLatency,
      );

      // Si mientras cargábamos se escogió otro preset, estos pools ya no son
      // válidos para el estado actual y deben descartarse.
      if (generation != _audioLoadGeneration) {
        await accent.dispose();
        await normal.dispose();
        return;
      }

      _accentPool = accent;
      _normalPool = normal;
      _audioReady = true;
      debugPrint('Audio del metrónomo listo: ${preset.name}');
    } catch (e, stackTrace) {
      if (generation == _audioLoadGeneration) {
        _audioReady = false;
      }
      debugPrint(
        'Error inicializando audio del metrónomo (${preset.name}): $e',
      );
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  Future<void> _ensureAudioReady() async {
    final pending = _audioLoadFuture;
    if (pending != null) {
      await pending;
    }

    // Si la carga inicial falló, intentar una carga nueva del preset actual.
    if (!_audioReady) {
      _audioLoadFuture = _loadAudioForPreset(state.soundPresetId);
      await _audioLoadFuture;
    }
  }

  void setBpm(int newBpm) {
    final clampedBpm = newBpm.clamp(40, 240);
    state = state.copyWith(bpm: clampedBpm);
    if (state.isPlaying) {
      _restartTimerKeepingBeat();
    }
  }

  void adjustBpm(int delta) {
    setBpm(state.bpm + delta);
  }

  void setTimeSignature(int signature) {
    state = state.copyWith(timeSignature: signature, currentBeat: 0);
    if (state.isPlaying) {
      _restartTimerKeepingBeat();
    }
  }

  Future<void> togglePlay() async {
    if (state.isPlaying) {
      _stopTimer();
      state = state.copyWith(isPlaying: false, currentBeat: 0);
      return;
    }

    // Play espera a que el preset actual esté realmente listo. Así el primer
    // tick nunca se pierde por una carga asíncrona pendiente.
    await _ensureAudioReady();

    if (state.isPlaying) return;

    state = state.copyWith(isPlaying: true, currentBeat: 0);

    if (!state.isMuted) {
      await _playClickSound(isAccent: true);
    }

    _scheduleNextTick();
  }

  void toggleMute() {
    state = state.copyWith(isMuted: !state.isMuted);
  }

  void registerTap() {
    final now = DateTime.now();
    _tapTimes.add(now);

    _tapTimes.removeWhere((time) => now.difference(time).inMilliseconds > 3000);

    if (_tapTimes.length >= 2) {
      final List<int> intervals = [];
      for (int i = 1; i < _tapTimes.length; i++) {
        intervals.add(_tapTimes[i].difference(_tapTimes[i - 1]).inMilliseconds);
      }
      final double avgInterval =
          intervals.reduce((a, b) => a + b) / intervals.length;
      final int calculatedBpm = (60000 / avgInterval).round();

      setBpm(calculatedBpm);
    }
  }

  void _scheduleNextTick() {
    _stopTimer();

    final intervalMs = ((60 / state.bpm) * 1000).round();
    _timer = Timer(Duration(milliseconds: intervalMs), _onScheduledTick);
  }

  void _onScheduledTick() {
    if (!state.isPlaying) return;

    _tick();
    _scheduleNextTick();
  }

  void _restartTimerKeepingBeat() {
    if (!state.isPlaying) return;
    _scheduleNextTick();
  }

  void _stopTimer() {
    _timer?.cancel();
    _timer = null;
  }

  void _tick() {
    final nextBeat = (state.currentBeat + 1) % state.timeSignature;
    state = state.copyWith(currentBeat: nextBeat);

    if (!state.isMuted) {
      unawaited(_playClickSound(isAccent: nextBeat == 0));
    }
  }

  Future<void> _playClickSound({required bool isAccent}) async {
    if (state.isMuted || !_audioReady) return;

    final pool = isAccent ? _accentPool : _normalPool;
    if (pool == null) return;

    try {
      await pool.start();
    } catch (e) {
      debugPrint('Error reproduciendo tick del metrónomo: $e');
    }
  }

  @override
  void dispose() {
    _stopTimer();
    _accentPool?.dispose();
    _normalPool?.dispose();
    super.dispose();
  }
}

final metronomeProvider =
    StateNotifierProvider<MetronomeNotifier, MetronomeState>((ref) {
      return MetronomeNotifier();
    });
